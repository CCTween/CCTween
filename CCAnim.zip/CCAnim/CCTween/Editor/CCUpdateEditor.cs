﻿//*********************************************************************
//
//							ScriptName:	CCUpdateEditor
//
//							Project	  : CCAnim
//
//*********************************************************************

using UnityEngine;
using System.Collections;
using UnityEditor;

[CustomEditor(typeof(CCUpdate))]
public class CCUpdateEditor : Editor {

    public override void OnInspectorGUI()
    {
    }
}
