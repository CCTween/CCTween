﻿//*********************************************************************
//
//							ScriptName:	CCDelayEditor
//
//							Project	  : CCAnim
//
//*********************************************************************

using UnityEngine;
using System.Collections;

public class CCDelayEditor : MonoBehaviour {


	void Start () {
	
	}
	
	void Update () {
	
	}
}
